import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Client, GatewayIntentBits, AttachmentBuilder, EmbedBuilder } from 'discord.js';
import open, { apps } from 'open';
import { spawn } from 'node:child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOGO_PATH = path.join(__dirname, 'logo.png');

// ---------- config (from .env) ----------
const TOKEN = process.env.DISCORD_TOKEN;
const KEYWORDS = (process.env.KEYWORDS || 'search').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
const ALLOWED_USER_ID = process.env.ALLOWED_USER_ID || '';       // optional: only this user may trigger the bot
const ALLOWED_CHANNEL_ID = process.env.ALLOWED_CHANNEL_ID || ''; // optional: only this channel
const ENGINE_COUNT = Number(process.env.ENGINE_COUNT || 5);
const SET_AVATAR = String(process.env.SET_AVATAR || 'false').toLowerCase() === 'true';
// MODE=link (default): reply with one link to the Max Impact Search page for the search term.
// MODE=browser: open the search in browser tabs on this machine (see the launcher settings below).
const MODE = (process.env.MODE || 'link').trim().toLowerCase();
const SEARCH_PAGE = (process.env.SEARCH_PAGE || 'https://llarryyllarryy.github.io/Max-Impact-Search/index.html').trim();
// LINKS_ONLY=true (browser mode only): never try to open a browser, just reply with clickable links (for servers / machines without a screen)
const LINKS_ONLY = String(process.env.LINKS_ONLY || 'false').toLowerCase() === 'true';

if (!TOKEN) {
  console.error('Missing DISCORD_TOKEN. Copy .env.example to .env and paste your bot token.');
  process.exit(1);
}

// ---------- search engines ----------
const engines = [
  { key:'ecosia',    label:'Ecosia',    build:x => 'https://www.ecosia.org/search?method=index&q=' + x },
  { key:'oceanhero', label:'OceanHero', build:x => 'https://oceanhero.today/web?q=' + x },
  { key:'rapusia',   label:'Rapusia',   build:x => 'https://rapusia.org/?q=' + x },
  { key:'gexsi',     label:'Gexsi',     build:x => 'https://gexsi.com/search/?q=' + x + '#gsc.tab=0&gsc.q=' + x + '&gsc.page=1' },
  { key:'ekoru',     label:'Ekoru',     build:x => 'https://ekoru.org/?q=' + x },
];

// Fisher-Yates shuffle, then take the first n
function pickRandom(arr, n) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, Math.min(n, a.length));
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

// Optional: force a specific browser instead of the OS default.
// SEARCH_BROWSER=chrome | firefox | edge | brave | full path to the browser executable
// (named SEARCH_BROWSER on purpose: many systems/hosts already define a generic BROWSER variable)
const BROWSER = (process.env.SEARCH_BROWSER || '').trim();
const APP = BROWSER ? { name: apps[BROWSER.toLowerCase()] || BROWSER } : undefined;

// LAUNCHER=open (default): open links in the local system default browser (via the "open" package).
// LAUNCHER=chrome-launcher: find Chrome with the "chrome-launcher" package first, then fall back to "open".
// Set CHROME_PATH in .env to point at a specific Chrome/Chromium executable (chrome-launcher only).
const LAUNCHER = (process.env.LAUNCHER || 'open').trim().toLowerCase();

// chrome-launcher is only loaded when requested, so the bot starts even if it isn't installed.
let ChromeLauncher = null;
if (LAUNCHER === 'chrome-launcher') {
  try {
    ChromeLauncher = await import('chrome-launcher');
  } catch (err) {
    console.warn('[chrome-launcher] package not installed (run "npm install"). Using the system default browser instead.');
  }
}

// Runs a command and resolves true if it started and exited with code 0.
function run(cmd, args) {
  return new Promise(resolve => {
    try {
      const child = spawn(cmd, args, { stdio: 'ignore', windowsHide: true });
      child.once('error', err => { console.error(`[launcher] ${cmd} failed:`, err.message); resolve(false); });
      child.once('exit', code => resolve(code === 0));
    } catch (err) {
      console.error(`[launcher] ${cmd} failed:`, err.message);
      resolve(false);
    }
  });
}

// ---------- chrome-launcher ----------
let chromePath; // undefined = not looked up yet, null = not found

function getChromePath() {
  if (chromePath === undefined) {
    try {
      chromePath = ChromeLauncher.Launcher.getFirstInstallation() || null;
      console.log(`[chrome-launcher] Chrome found: ${chromePath}`);
    } catch (err) {
      chromePath = null;
      console.error('[chrome-launcher] No Chrome/Chromium installation found:', err.message);
    }
  }
  return chromePath;
}

// Starts Chrome with the URL. If Chrome is already running, this adds a new tab to it.
// Resolves true if it exited 0 (handed over to the running Chrome) or is still running after 2s (it is the browser).
function launchWithChrome(url) {
  if (!ChromeLauncher) return Promise.resolve(false);
  const exe = getChromePath();
  if (!exe) return Promise.resolve(false);
  return new Promise(resolve => {
    let done = false;
    const finish = v => { if (!done) { done = true; resolve(v); } };
    try {
      const child = spawn(exe, [url], { stdio: 'ignore', detached: true, windowsHide: false });
      child.once('error', err => { console.error('[chrome-launcher] spawn failed:', err.message); finish(false); });
      child.once('exit', code => {
        if (code !== 0) console.error(`[chrome-launcher] Chrome exited with code ${code} (no display / desktop session?)`);
        finish(code === 0);
      });
      child.unref();
      setTimeout(() => finish(true), 2000);
    } catch (err) {
      console.error('[chrome-launcher] failed:', err.message);
      finish(false);
    }
  });
}

// Opens a URL in the local default browser ("open" package, then OS-native launcher).
// With LAUNCHER=chrome-launcher, Chrome is tried first.
async function openUrl(url) {
  // 0) chrome-launcher (only if enabled)
  if (LAUNCHER === 'chrome-launcher' && await launchWithChrome(url)) return true;

  // 1) "open" package; wait for its process so failures are detected
  try {
    const child = await open(url, APP ? { app: APP } : undefined);
    const ok = await new Promise(resolve => {
      let done = false;
      const finish = v => { if (!done) { done = true; resolve(v); } };
      child.once('error', err => { console.error('[launcher] open error:', err.message); finish(false); });
      child.once('exit', code => finish(code === 0 || code === null));
      setTimeout(() => finish(true), 3000); // still running after 3s = assume it worked
    });
    if (ok) return true;
  } catch (err) {
    console.error('[launcher] open threw:', err.message);
  }

  // 2) fallback: OS-native launcher
  console.log('[launcher] trying native fallback...');
  if (process.platform === 'win32') return run('rundll32', ['url.dll,FileProtocolHandler', url]);
  if (process.platform === 'darwin') return run('open', [url]);
  return run('xdg-open', [url]);
}

// ---------- discord client ----------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('clientReady', async () => {
  console.log(`Logged in as ${client.user.tag}`);
  console.log(`Trigger keywords: ${KEYWORDS.join(', ')}`);
  console.log(`Mode: ${MODE}` + (MODE === 'browser'
    ? ` | Launcher: ${LAUNCHER} | Browser: ${BROWSER || 'system default'} | Links only: ${LINKS_ONLY}`
    : ` | Search page: ${SEARCH_PAGE}`));

  if (SET_AVATAR) {
    try {
      await client.user.setAvatar(LOGO_PATH);
      console.log('Bot avatar updated from logo.png (set SET_AVATAR=false in .env to stop doing this).');
    } catch (err) {
      console.warn('Could not set avatar (Discord rate-limits avatar changes):', err.message);
    }
  }
});

client.on('messageCreate', async (msg) => {
  if (msg.author.bot) return;
  if (ALLOWED_USER_ID && msg.author.id !== ALLOWED_USER_ID) return;
  if (ALLOWED_CHANNEL_ID && msg.channelId !== ALLOWED_CHANNEL_ID) return;

  const content = msg.content.trim();
  const lower = content.toLowerCase();

  const keyword = KEYWORDS.find(k => lower.startsWith(k + ' '));
  if (!keyword) return;

  const query = content.slice(keyword.length).trim();
  if (!query) return;

  const encoded = encodeURIComponent(query);

  // Default mode: just return the Max Impact Search link for this term
  if (MODE !== 'browser') {
    const url = `${SEARCH_PAGE}?search=${encoded}`;
    const safeUrl = url.replace(/\(/g, '%28').replace(/\)/g, '%29'); // keep markdown links intact
    const logo = new AttachmentBuilder(LOGO_PATH, { name: 'logo.png' });
    const embed = new EmbedBuilder()
      .setTitle('Do a good deed with this search')
      .setDescription(`[${query.length > 100 ? query.slice(0, 97) + '...' : query}](${safeUrl})`)
      .setThumbnail('attachment://logo.png');
    console.log(`[search] link for "${query}": ${url}`);
    await msg.reply({ content: 'Do a good deed with this search:', embeds: [embed], files: [logo] }).catch(console.error);
    return;
  }

  const chosen = pickRandom(engines, ENGINE_COUNT);

  const opened = []; // engines opened in the local browser
  const failed = []; // engines that could not be opened (shown as clickable links instead)
  let browserUnavailable = LINKS_ONLY;
  for (const e of chosen) {
    if (browserUnavailable) { failed.push(e); continue; }
    const ok = await openUrl(e.build(encoded));
    (ok ? opened : failed).push(e);
    console.log(`[search] ${e.label}: ${ok ? 'opened' : 'FAILED'}`);
    // If nothing has opened yet and this one failed, this machine can't open a browser: skip the rest.
    if (!ok && opened.length === 0) {
      browserUnavailable = true;
      console.log('[search] No browser could be opened on this machine; replying with links instead.');
    }
    await sleep(400); // small gap so the browser isn't flooded
  }

  // Markdown-safe clickable links for the engines that were not opened
  const links = failed
    .map(e => `[${e.label}](${e.build(encoded).replace(/\(/g, '%28').replace(/\)/g, '%29')})`)
    .join('\n');

  const title = failed.length === 0 ? 'Search opened'
    : opened.length ? 'Search partly opened'
    : LINKS_ONLY ? 'Search links'
    : 'No browser available, open the links';

  const logo = new AttachmentBuilder(LOGO_PATH, { name: 'logo.png' });
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(
      `**${query}**\n` +
      (opened.length ? `Opened: ${opened.map(e => e.label).join(' · ')}\n` : '') +
      (links ? `${opened.length ? 'Not opened, click:' : 'Click to search:'}\n${links}` : '')
    )
    .setThumbnail('attachment://logo.png');

  await msg.reply({ embeds: [embed], files: [logo] }).catch(console.error);
});

client.login(TOKEN);

@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies...
  call npm install
)
if not exist .env (
  copy .env.example .env >nul
  echo.
  echo Created .env - open it, paste your bot token, save, then run start.bat again.
  notepad .env
  pause
  exit /b
)
node bot.mjs
pause

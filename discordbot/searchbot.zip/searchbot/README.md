# SearchBot

A Discord bot that opens your browser when someone writes `search <something>` in a channel.
It opens the query in 5 search engines (Ecosia, OceanHero, Rapusia, Gexsi, Ekoru), in random order.

The bot must run on the computer whose browser should open.

## 1. Create the bot (once)
1. Go to https://discord.com/developers/applications -> **New Application**.
2. **Bot** tab -> **Reset Token** / copy the token.
3. Same tab -> enable **Message Content Intent**.
4. **OAuth2 -> URL Generator** -> tick `bot`, permissions *View Channels*, *Send Messages*, *Embed Links*, *Attach Files*. Open the generated URL to invite the bot to your server.

## 2. Install Node.js
Version 18 or newer (22 recommended) from https://nodejs.org

## 3. Configure
Copy `.env.example` to `.env` and paste your token after `DISCORD_TOKEN=`.
(`start.bat` / `start.sh` do this copy for you on the first run.)

## 4. Run
- **Windows:** double-click `start.bat`
- **macOS / Linux:** `chmod +x start.sh && ./start.sh`
- or manually: `npm install` then `npm start`

You should see `Logged in as ...`. Then write `search best pizza recipe` in your server.

## Logo
`logo.png` is shown in the bot's reply embed. To also use it as the bot's profile picture, set `SET_AVATAR=true` in `.env`, start the bot once, then set it back to `false` (Discord limits how often avatars can change). You can also upload it manually in the Developer Portal under **General Information -> App Icon** and **Bot -> Icon**.

## Settings (.env)
| Variable | Meaning |
|---|---|
| `DISCORD_TOKEN` | Your bot token (keep it secret, never share the `.env` file) |
| `KEYWORDS` | Trigger words, comma separated, e.g. `search,find,lookup` |
| `ALLOWED_USER_ID` | Only this Discord user can trigger the bot (recommended) |
| `ALLOWED_CHANNEL_ID` | Only this channel can trigger the bot |
| `LAUNCHER` | `open` (default, your local system default browser) or `chrome-launcher` (Chrome first, then default browser) |
| `CHROME_PATH` | Full path to Chrome/Chromium if it isn't found automatically |
| `SEARCH_BROWSER` | Force a browser: `chrome`, `firefox`, `edge`, `brave` or a full path. Empty = system default |
| `LINKS_ONLY` | `true` = never open a browser, reply with clickable links (for servers). Automatic fallback when no browser can be opened |
| `ENGINE_COUNT` | How many engines to open per search |
| `SET_AVATAR` | `true` once to apply `logo.png` as profile picture |

## Troubleshooting: "Search opened" but no browser
The bot only opens a browser on the computer it runs on. Check:
- **Where is it running?** A server, VPS, Docker container, Replit or other hosting has no screen or browser, so nothing can open. Run it on your own PC.
- **WSL?** Run it from normal Windows PowerShell/cmd instead of inside WSL.
- **Terminal output.** For every engine the bot prints `[search] Name: opened` or `FAILED`, plus the error. The Discord reply also lists which engines failed.
- **Default browser.** Make sure your OS has a default web browser set.
- **Several bot copies running?** An old instance on another machine will answer too. Stop all others (or reset the token).

## Security
Anyone who can post where the bot listens can make your browser open tabs. Set `ALLOWED_USER_ID` (and ideally `ALLOWED_CHANNEL_ID`).

## Adding engines
Add an entry to the `engines` array in `bot.mjs`:
```js
{ key:'name', label:'Name', build:x => 'https://example.com/?q=' + x },
```

#!/usr/bin/env bash
cd "$(dirname "$0")"
if [ ! -d node_modules ]; then
  echo "Installing dependencies..."
  npm install
fi
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env - open it, paste your bot token, save, then run ./start.sh again."
  exit 0
fi
node bot.mjs
